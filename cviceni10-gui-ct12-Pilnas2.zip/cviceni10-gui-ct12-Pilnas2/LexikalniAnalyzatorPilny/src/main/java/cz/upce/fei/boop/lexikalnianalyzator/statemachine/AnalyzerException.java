package cz.upce.fei.boop.lexikalnianalyzator.statemachine;

/**
 *
 * @author karel@simerda.cz
 */
public class AnalyzerException extends RuntimeException {

    public AnalyzerException(String message) {
        super(message);
    }
    
}
