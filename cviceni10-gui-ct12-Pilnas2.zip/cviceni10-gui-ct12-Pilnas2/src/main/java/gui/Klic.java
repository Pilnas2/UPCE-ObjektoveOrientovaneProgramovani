/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import data.Letadla;
import data.TypLetadla;

/**
 *
 * @author marti
 */
public class Klic extends Letadla{

    public Klic( String cisloLetu) {
        super(TypLetadla.KLIC, cisloLetu);
    }
    
    
    
    
}
