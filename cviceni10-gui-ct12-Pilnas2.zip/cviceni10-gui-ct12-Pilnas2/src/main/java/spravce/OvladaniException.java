/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package spravce;

/**
 *
 * @author marti
 */
public class OvladaniException extends Exception {

    public OvladaniException() {
    }

    public OvladaniException(String message) {
        super(message);
    }
    
}
