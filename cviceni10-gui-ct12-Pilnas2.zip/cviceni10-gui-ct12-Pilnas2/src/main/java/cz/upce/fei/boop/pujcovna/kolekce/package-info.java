package cz.upce.fei.boop.pujcovna.kolekce;

/*
Balíček je určen pro zdrojové soubory spojového seznamu nebo případně dalších
typů kolekcí.
*/
